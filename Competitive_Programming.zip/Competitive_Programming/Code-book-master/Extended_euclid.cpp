
Writing the code for extended euclidean algorithm ,  can be used to find mod inverse when a and MOD are coprime that is gcd  =  1 


extend_euclid (  )
 {
     int x = 1 ;
     int xlast = 0 ; 
     int y = 0  ; 
     int ylast = 1 ; 

     while ( a )
      {
           q = b/a   ; 
           r = b%a   ;
 
           m = xlast - q*x ; 
           n = ylast - q*y ;    
           
           x = m ; 
           y = n ;
           
           a = r ;
           b = a ;


      }
    
    // ax + by = gcd( a,b )
    // x will be equal to xlast  , y will be equal to ylast  and gcd =  b  


 }

